"use strict";
const NS = "http://www.w3.org/2000/svg";
let S = null, csrf = "", tab = "Огляд", sym = "BTC/USDT:USDT", tf = "1h", kind = "candles", ctab = "Ціна", candles = [], nextAt = 0, timerRefs = null, msg = "";
const TABS = ["Огляд", "Сигнали", "Біржі", "Налаштування", "Сповіщення"];
const $ = (id) => document.getElementById(id);
function h(tag, a, ...kids) {
  const e = document.createElement(tag);
  for (const k in (a || {})) { const v = a[k]; if (v === null || v === undefined || v === false) continue; if (k === "class") e.className = v; else if (k.startsWith("on")) e[k] = v; else e.setAttribute(k, v); }
  for (const c of kids.flat()) if (c !== null && c !== undefined && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c)));
  return e;
}
function sv(tag, a, ...kids) {
  const e = document.createElementNS(NS, tag);
  for (const k in (a || {})) e.setAttribute(k, a[k]);
  kids.flat().forEach((c) => c && e.append(c));
  return e;
}
const fmt = (x, d = 2) => (x === null || x === undefined || isNaN(x)) ? "—" : Number(x).toLocaleString("en-US", { maximumFractionDigits: d });
const pr = (x) => x >= 100 ? fmt(x, 1) : x >= 1 ? fmt(x, 3) : fmt(x, 6);
async function api(p, o) {
  o = o || {};
  const r = await fetch(p, { ...o, headers: { "Content-Type": "application/json", "X-CSRF": csrf }, credentials: "same-origin" });
  if (r.status === 401) { location.href = "/login"; return null; }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || ("помилка " + r.status));
  return j;
}
function icon(n) {
  const P = { search: "M11 11l4 4M7 12a5 5 0 110-10 5 5 0 010 10z", bell: "M8 2a4 4 0 00-4 4v3l-1 2h10l-1-2V6a4 4 0 00-4-4zM6.5 13a1.5 1.5 0 003 0", wallet: "M2 4h11v9H2zM2 4l9-2v2M10 8h3", line: "M2 12l4-5 3 3 5-7", cand: "M5 2v12M11 4v9M3 5h4v6H3zM9 6h4v5H9z", info: "M8 7v4M8 4.5v.5M8 15A7 7 0 118 1a7 7 0 010 14z", trend: "M2 12l4-4 3 3 5-6M10 5h4v4", dollar: "M8 2v12M11 5H7a2 2 0 000 4h2a2 2 0 010 4H5", bars: "M3 13V8M8 13V3M13 13V6", out: "M2 8h12M10 4l4 4-4 4" };
  return sv("svg", { viewBox: "0 0 16 16", width: 16, height: 16, fill: "none", stroke: "currentColor", "stroke-width": 1.4, "stroke-linecap": "round", "stroke-linejoin": "round" }, sv("path", { d: P[n] }));
}
function smooth(pts) {
  let d = "M" + pts[0][0] + "," + pts[0][1];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    d += "C" + (p1[0] + (p2[0] - p0[0]) / 6) + "," + (p1[1] + (p2[1] - p0[1]) / 6) + "," + (p2[0] - (p3[0] - p1[0]) / 6) + "," + (p2[1] - (p3[1] - p1[1]) / 6) + "," + p2[0] + "," + p2[1];
  }
  return d;
}
function spark(vals, col, id, marker) {
  const W = 260, H = 92;
  let v = vals.filter((x) => x !== null && x !== undefined && !isNaN(x));
  const flat = v.length < 2;
  if (flat) v = [0, 0, 0];
  const mn = Math.min(...v), mx = Math.max(...v), rg = (mx - mn) || 1;
  const pts = v.map((x, i) => [i * W / (v.length - 1), flat ? H * 0.6 : H - 16 - ((x - mn) / rg) * (H - 36)]);
  const d = smooth(pts), last = pts[pts.length - 1];
  const g = sv("linearGradient", { id: "g" + id, x1: 0, y1: 0, x2: 0, y2: 1 }, sv("stop", { offset: "0", "stop-color": col, "stop-opacity": ".32" }), sv("stop", { offset: "1", "stop-color": col, "stop-opacity": "0" }));
  const f = sv("filter", { id: "f" + id, x: "-20%", y: "-50%", width: "140%", height: "200%" }, sv("feGaussianBlur", { stdDeviation: "3", result: "b" }), sv("feMerge", {}, sv("feMergeNode", { in: "b" }), sv("feMergeNode", { in: "SourceGraphic" })));
  const out = sv("svg", { viewBox: "0 0 " + W + " " + H, preserveAspectRatio: "none" }, sv("defs", {}, g, f),
    flat ? null : sv("path", { d: d + "L" + W + "," + H + "L0," + H + "Z", fill: "url(#g" + id + ")" }),
    sv("path", { d, fill: "none", stroke: col, "stroke-width": 2, filter: "url(#f" + id + ")", "stroke-dasharray": flat ? "4 4" : "none", "stroke-linecap": "round" }));
  if (marker && !flat) { out.append(sv("line", { x1: last[0], x2: last[0], y1: 8, y2: H, stroke: "#fff", "stroke-opacity": ".25", "stroke-dasharray": "2 3" }), sv("circle", { cx: last[0], cy: last[1], r: 3, fill: "#fff" })); }
  return out;
}
function stat(title, val, chg, dn, vals, col, id, marker, glow) {
  return h("div", { class: "card stat" }, glow ? h("div", { class: "glowr" }) : null, h("h4", {}, title), h("div", { class: "v" }, val), h("div", { class: "chg" + (dn ? " dn" : "") }, chg), spark(vals, col, id, marker));
}
function ringTimer() {
  const R = 56, C = 2 * Math.PI * R;
  const g = sv("linearGradient", { id: "tg", x1: 0, y1: 0, x2: 1, y2: 1 }, sv("stop", { offset: "0", "stop-color": "#ffb020" }), sv("stop", { offset: "1", "stop-color": "#ff3b30" }));
  const arc = sv("circle", { cx: 66, cy: 66, r: R, fill: "none", stroke: "url(#tg)", "stroke-width": 8, "stroke-linecap": "round", "stroke-dasharray": C, "stroke-dashoffset": 0 });
  const svg = sv("svg", { viewBox: "0 0 132 132" }, sv("defs", {}, g), sv("circle", { cx: 66, cy: 66, r: R, fill: "none", stroke: "#1b2030", "stroke-width": 8 }), arc);
  const t = h("b", {}, "00:00");
  timerRefs = { arc, t, C };
  return h("div", { class: "ring" }, svg, h("div", { class: "c" }, h("small", {}, "Наступний скан"), t));
}
function tick() {
  if (!timerRefs) return;
  const left = Math.max(0, Math.round((nextAt - Date.now()) / 1000));
  timerRefs.t.textContent = String(Math.floor(left / 60)).padStart(2, "0") + ":" + String(left % 60).padStart(2, "0");
  timerRefs.arc.setAttribute("stroke-dashoffset", timerRefs.C * Math.min(1, left / 900));
}
function segRing(pct) {
  const n = 36, lit = pct === null ? 0 : Math.round(n * pct / 100), svg = sv("svg", { viewBox: "0 0 150 150" });
  const f = sv("filter", { id: "sg", x: "-30%", y: "-30%", width: "160%", height: "160%" }, sv("feGaussianBlur", { stdDeviation: "2.2", result: "b" }), sv("feMerge", {}, sv("feMergeNode", { in: "b" }), sv("feMergeNode", { in: "SourceGraphic" })));
  svg.append(sv("defs", {}, f));
  for (let i = 0; i < n; i++) {
    const a = (i / n) * 2 * Math.PI - Math.PI / 2, r1 = 56, r2 = 70, on = i < lit;
    svg.append(sv("line", { x1: 75 + Math.cos(a) * r1, y1: 75 + Math.sin(a) * r1, x2: 75 + Math.cos(a) * r2, y2: 75 + Math.sin(a) * r2, stroke: on ? "#3df08a" : "#26303a", "stroke-width": 5, "stroke-linecap": "round", filter: on ? "url(#sg)" : "none", opacity: on ? 1 : .7 }));
  }
  return svg;
}
function chartSvg() {
  const W = Math.max(300, Math.round(($("app").clientWidth || 360) - (window.innerWidth < 900 ? 64 : 330 - 0))), H = 300, PR = 62, PB = 24;
  const svg = sv("svg", { viewBox: "0 0 " + W + " " + H, width: W, height: H, class: "cv" });
  const all = candles; candles = candles.slice(-Math.max(20, Math.floor((W - PR) / 7)));
  if (!candles.length) { svg.append(sv("text", { x: W / 2, y: H / 2, fill: "#8b93a7", "text-anchor": "middle", "font-size": 14 }, msg || "завантажую свічки…")); return svg; }
  const lo0 = Math.min(...candles.map((c) => c[3])), hi0 = Math.max(...candles.map((c) => c[2]));
  const sig = (S.signals || []).find((x) => x.symbol === sym);
  let lo = lo0, hi = hi0;
  if (sig) { lo = Math.min(lo, sig.sl); hi = Math.max(hi, sig.tp); }
  const pad = (hi - lo) * 0.06; lo -= pad; hi += pad;
  const y = (p) => 10 + (H - PB - 10) * (1 - (p - lo) / (hi - lo)), cw = (W - PR) / candles.length;
  const f = sv("filter", { id: "cg", x: "-50%", y: "-20%", width: "200%", height: "140%" }, sv("feGaussianBlur", { stdDeviation: "3.2", result: "b" }), sv("feMerge", {}, sv("feMergeNode", { in: "b" }), sv("feMergeNode", { in: "SourceGraphic" })));
  svg.append(sv("defs", {}, f));
  for (let i = 0; i < 5; i++) {
    const p = lo + (hi - lo) * i / 4, yy = y(p);
    svg.append(sv("line", { x1: 0, x2: W - PR, y1: yy, y2: yy, stroke: "#fff", "stroke-opacity": ".07" }), sv("text", { x: W - PR + 8, y: yy + 4, fill: "#8b93a7", "font-size": 11 }, p >= 1000 ? fmt(p, 0) : pr(p)));
  }
  const dates = [0, .17, .34, .51, .68, .85].map((k) => candles[Math.floor(k * (candles.length - 1))]);
  dates.forEach((c, i) => svg.append(sv("text", { x: 10 + i * (W - PR - 40) / 5, y: H - 6, fill: "#8b93a7", "font-size": 11 }, new Date(c[0]).toLocaleDateString("uk", { day: "numeric", month: "short" }) + (tf !== "1d" ? " " + new Date(c[0]).getHours() + ":00" : ""))));
  const gl = sv("g", { filter: "url(#cg)" });
  candles.forEach((c, i) => {
    const up = c[4] >= c[1], col = up ? "#35ff86" : "#ff5a5f", x = i * cw + cw / 2;
    if (kind === "candles") {
      gl.append(sv("line", { x1: x, x2: x, y1: y(c[2]), y2: y(c[3]), stroke: col, "stroke-width": 1.4 }), sv("rect", { x: x - cw * 0.3, y: Math.min(y(c[1]), y(c[4])), width: cw * 0.6, height: Math.max(1.5, Math.abs(y(c[1]) - y(c[4]))), fill: col, rx: 1.2 }));
    }
  });
  if (kind === "line") gl.append(sv("path", { d: smooth(candles.map((c, i) => [i * cw + cw / 2, y(c[4])])), fill: "none", stroke: "#4a7dff", "stroke-width": 2.4 }));
  svg.append(gl);
  if (sig) [["вхід", sig.entry, "#7aa2ff"], ["SL", sig.sl, "#ff5a5f"], ["TP", sig.tp, "#35ff86"]].forEach(([n, p, col]) => svg.append(sv("line", { x1: 0, x2: W - PR, y1: y(p), y2: y(p), stroke: col, "stroke-dasharray": "6 5", "stroke-opacity": ".85" }), sv("text", { x: 6, y: y(p) - 5, fill: col, "font-size": 11 }, n + " " + pr(p))));
  candles = all;
  return svg;
}
async function loadCandles() {
  msg = ""; candles = [];
  try { const j = await api("/api/candles?symbol=" + encodeURIComponent(sym) + "&tf=" + tf); candles = j.candles; } catch (e) { msg = "нема даних для " + sym; }
  if (tab === "Огляд") render();
}
function overview() {
  const H = S.history || [], sg = S.signals || [], eq = H.map((x) => x.equity), last = eq[eq.length - 1], first = eq[0];
  const edges = sg.filter((x) => x.tm).slice().reverse().map((x) => 100 * x.tm.p_tp / ((x.tm.p_tp + x.tm.p_sl) || 1));
  const fomo = sg.filter((x) => x.action === "FOMO-блок"), fcum = []; fomo.slice().reverse().forEach((_, i) => fcum.push(i + 1));
  const sen = S.status.sentiment || { bull: 0, bear: 0, none: 0 }, tot = (sen.bull + sen.bear + sen.none) || 1;
  const pc = (k) => Math.round(100 * sen[k] / tot);
  const ch = last !== undefined && first ? ((last - first) / first * 100) : 0;
  const syms = [...new Set(["BTC/USDT:USDT", "ETH/USDT:USDT", "SOL/USDT:USDT", "XRP/USDT:USDT", ...sg.map((x) => x.symbol)])];
  const lc = candles.length ? candles[candles.length - 1][4] : null, fc = candles.length ? candles[0][4] : null;
  const cc = lc && fc ? (lc - fc) / fc * 100 : 0;
  const strip = h("div", { class: "strip" },
    h("div", { class: "pill" }, h("span", { class: "sq g" }, icon("trend")), "Стратегія", h("span", { class: "tag" }, "Smart Money")),
    h("div", { class: "pill" }, h("span", { class: "sq a" }, icon("dollar")), "Режим", h("b", {}, S.settings.mode + (S.settings.auto ? " · авто" : "") + (S.settings.stop ? " · STOP" : ""))),
    h("div", { class: "pill" }, h("span", { class: "sq p" }, icon("bars")), "Біржі", h("b", {}, S.exchanges.length ? S.exchanges.length + " підключено" : "публічні дані")));
  const sel = h("select", { class: "sel", onchange: (e) => { sym = e.target.value; loadCandles(); } }, syms.map((s) => h("option", { value: s, selected: s === sym ? "" : null }, s.replace(":USDT", ""))));
  const tfs = h("div", { class: "seg" }, ["15m", "1h", "4h", "1d"].map((t) => h("button", { class: t === tf ? "on" : "", onclick: () => { tf = t; loadCandles(); } }, t)));
  const kinds = h("div", { class: "seg" }, h("button", { class: kind === "line" ? "on" : "", onclick: () => { kind = "line"; render(); } }, icon("line")), h("button", { class: kind === "candles" ? "on" : "", onclick: () => { kind = "candles"; render(); } }, icon("cand")));
  const ctabs = h("div", { class: "seg" }, ["Ціна", "Сигнали"].map((t) => h("button", { class: t === ctab ? "on" : "", onclick: () => { ctab = t; render(); } }, t)));
  const chartBody = ctab === "Ціна" ? [h("div", { class: "pr" }, sym.replace(":USDT", ""), " ", lc ? pr(lc) : "—", h("small", { class: cc < 0 ? "dn" : "" }, (cc >= 0 ? "+" : "") + fmt(cc) + "% ▴")), chartSvg()] : [signalList(sg.slice(0, 8))];
  return h("div", { class: "grid" },
    stat("Баланс рахунку", "$" + fmt(last !== undefined ? last : S.settings.deposit), (ch >= 0 ? "+" : "") + fmt(ch) + "% ▴", ch < 0, eq, "#5a8bff", "a"),
    stat("Сигнали, 7 днів", String(H.length ? H[H.length - 1].sig7 : 0), "скановано " + S.status.scanned + " монет", false, H.map((x) => x.sig7), "#4a7dff", "b", true),
    stat("Edge Машини часу", S.edge === null ? "—" : S.edge + "%", "ціль першою серед завершених", S.edge !== null && S.edge < 40, edges, "#ff4d5a", "c", false, true),
    stat("Анти-FOMO блоки", String(fomo.length), "відхилені запізнілі входи", false, fcum, "#ff3d8b", "d"),
    h("div", { class: "card timer" }, h("div", { class: "hd" }, "Таймер скану", icon("info")), ringTimer(), h("button", { class: "btn", onclick: async () => { await api("/api/scan", { method: "POST", body: "{}" }); msg = "скан запущено"; render(); } }, S.status.running ? "Скан іде…" : "Сканувати зараз")),
    strip,
    h("div", { class: "card chartc" }, h("div", { class: "tb" }, ctabs, kinds, sel, tfs), chartBody),
    h("div", { class: "card sent" }, h("div", { class: "hd" }, "Настрій ринку (H4)", icon("info")),
      h("div", { class: "bars" }, [["bull", "linear-gradient(180deg,#46ff98,#1fd46c)"], ["none", "#c4c9d4"], ["bear", "linear-gradient(180deg,#ff6b6f,#e03a42)"]].map(([k, bg]) => { const e = h("i", {}); e.style.flex = String(Math.max(pc(k), 6)); e.style.background = bg; return e; })),
      h("div", { class: "lab" }, [["bull", "Бичачі", "#3df08a"], ["none", "Нейтр.", "#aab"], ["bear", "Ведмежі", "#ff5a5f"]].map(([k, n, c]) => { const d = h("div", {}, h("b", {}, pc(k) + "%"), n); d.style.flex = String(Math.max(pc(k), 6)); d.firstChild.style.color = c; return d; }))),
    h("div", { class: "card conf" }, h("div", { class: "hd" }, "Edge Машини часу", icon("info")), h("div", { class: "r" }, segRing(S.edge), h("b", {}, S.edge === null ? "—" : S.edge + "%")), h("p", {}, S.edge === null ? "Ще не було сигналів із симуляцією." : "Симуляція зі свічок монети, не прогноз.")));
}
function signalList(list) {
  if (!list.length) return h("p", { class: "mut" }, "Сигналів поки нема. Фільтр суворий, це нормально.");
  return h("div", {}, list.map((x) => h("div", { class: "row" }, h("b", { class: x.side === "long" ? "up" : "dn" }, x.side === "long" ? "КУПИТИ" : "ПРОДАТИ"), x.symbol.replace(":USDT", ""), h("span", { class: "mut" }, "[" + x.exchange + "]"), "вхід " + pr(x.entry), "SL " + pr(x.sl), "TP " + pr(x.tp), h("span", { class: "mut" }, new Date(x.t * 1000).toLocaleString("uk")), x.action ? h("span", { class: "mut" }, "· " + x.action) : null, x.note ? h("span", { class: "mut" }, "· " + x.note) : null)));
}
function exchangesTab() {
  const f = {};
  const field = (n, ph, t) => (f[n] = h("input", { placeholder: ph, type: t || "text", autocomplete: "off" }));
  const nameSel = h("select", {}, S.known.map((k) => h("option", { value: k }, k)));
  return h("div", { class: "card panel" }, h("h3", {}, "Біржі"), h("p", { class: "mut" }, "Ключі шифруються на сервері й назад не показуються. Права ключа: лише Trade, без Withdraw, з білим списком IP."),
    S.exchanges.map((e) => h("div", { class: "row" }, h("b", {}, e.name), h("span", { class: "mut" }, "ключ збережено"), h("button", { class: "btn warn", onclick: async () => { await api("/api/exchange/" + e.name, { method: "DELETE" }); await load(); tab = "Біржі"; render(); } }, "Видалити"))),
    h("div", { class: "row" }, nameSel, field("k", "API key"), field("s", "API secret", "password"), field("p", "passphrase (OKX)", "password"),
      h("button", { class: "btn", onclick: async () => { try { await api("/api/exchange", { method: "POST", body: JSON.stringify({ name: nameSel.value, key: f.k.value, secret: f.s.value, password: f.p.value }) }); f.k.value = f.s.value = f.p.value = ""; msg = "збережено"; await load(); tab = "Біржі"; render(); } catch (e) { msg = e.message; render(); } } }, "Додати")), msg ? h("p", { class: "mut" }, msg) : null);
}
function settingsTab() {
  const s = S.settings, el = {};
  const num = (k, l, step) => h("label", { class: "row" }, l, (el[k] = h("input", { type: "number", step: step || "any", value: s[k] })));
  const chk = (k, l) => h("label", { class: "row" }, (el[k] = h("input", { type: "checkbox", checked: s[k] ? "" : null })), l);
  el.mode = h("select", {}, ["paper", "live"].map((m) => h("option", { value: m, selected: m === s.mode ? "" : null }, m)));
  el.confirm = h("input", { placeholder: "фраза підтвердження для live" });
  return h("div", { class: "card panel" }, h("h3", {}, "Налаштування"),
    h("p", { class: "mut" }, "За замовчуванням paper і sandbox. Live вимагає ALLOW_LIVE=yes на сервері і фрази: ТОРГУВАТИ НА РЕАЛЬНІ ГРОШІ."),
    h("label", { class: "row" }, "Режим", el.mode), chk("auto", "Автоторгівля"), chk("sandbox", "Тестова біржа (sandbox)"),
    num("deposit", "Депозит $"), num("risk_pct", "Ризик на угоду %"), num("max_notional", "Макс. розмір позиції $"), num("max_trades_day", "Угод на день"), num("daily_loss_pct", "Денний ліміт збитку %"), num("min_edge", "Мін. edge Машини часу (0..1)", "0.01"), num("min_turnover", "Мін. обіг 24г $"), num("max_symbols", "Макс. монет"),
    el.confirm,
    h("div", { class: "row" }, h("button", { class: "btn", onclick: async () => { try { const b = {}; for (const k in el) { if (k === "confirm") continue; b[k] = el[k].type === "checkbox" ? el[k].checked : (el[k].tagName === "SELECT" ? el[k].value : Number(el[k].value)); } b.confirm = el.confirm.value; const r = await api("/api/settings", { method: "POST", body: JSON.stringify(b) }); S.settings = r.settings; msg = "збережено"; } catch (e) { msg = e.message; } render(); } }, "Зберегти"),
      h("button", { class: "btn warn", onclick: async () => { const r = await api("/api/stop", { method: "POST", body: "{}" }); S.settings = r.settings; msg = r.settings.stop ? "STOP увімкнено: бот не торгує" : "STOP вимкнено"; render(); } }, s.stop ? "Зняти STOP" : "STOP (вимкнути торгівлю)")), msg ? h("p", { class: "mut" }, msg) : null);
}
function b64u(s) { const p = "=".repeat((4 - s.length % 4) % 4), b = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(b, (c) => c.charCodeAt(0)); }
function notifyTab() {
  return h("div", { class: "card panel" }, h("h3", {}, "Сповіщення на телефон"),
    h("p", { class: "mut" }, "Push працює і коли сайт закрито: відкрий сайт на телефоні, «Додати на головний екран», потім увімкни тут. На iPhone потрібен iOS 16.4+. Додатково: ntfy і Telegram через змінні сервера."),
    h("div", { class: "row" }, h("span", {}, "Підписок: " + S.push.subs), h("button", { class: "btn", onclick: async () => { try { if (!S.push.key) throw new Error("на сервері не задано VAPID-ключі (gen_vapid.py)"); const reg = await navigator.serviceWorker.register("/sw.js"); if ((await Notification.requestPermission()) !== "granted") throw new Error("дозвіл не надано"); const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(S.push.key) }); await api("/api/push/subscribe", { method: "POST", body: JSON.stringify(sub.toJSON()) }); msg = "push увімкнено"; await load(); } catch (e) { msg = e.message; } tab = "Сповіщення"; render(); } }, "Увімкнути push"),
      h("button", { class: "btn alt", onclick: async () => { try { const r = await api("/api/test_notify", { method: "POST", body: "{}" }); msg = "надіслано push: " + r.sent; } catch (e) { msg = e.message; } render(); } }, "Тест")), msg ? h("p", { class: "mut" }, msg) : null);
}
function render() {
  const app = $("app"); if (!S) return;
  const view = tab === "Огляд" ? overview() : tab === "Сигнали" ? h("div", { class: "card panel" }, h("h3", {}, "Сигнали"), signalList(S.signals)) : tab === "Біржі" ? exchangesTab() : tab === "Налаштування" ? settingsTab() : notifyTab();
  app.replaceChildren(
    h("div", { class: "top" },
      h("div", { class: "logo" }, sv("svg", { viewBox: "0 0 24 24", width: 22, height: 22, fill: "none", stroke: "#fff", "stroke-width": 2.4, "stroke-linecap": "round" }, sv("path", { d: "M3 19L12 4l9 15M8 14h8" })), "Smart Money"),
      h("div", { class: "nav" }, TABS.map((t) => h("button", { class: t === tab ? "on" : "", onclick: () => { tab = t; msg = ""; render(); } }, t))),
      h("div", { class: "acts" }, h("div", { class: "ic" }, icon("search")), h("div", { class: "chip" }, icon("wallet"), S.status.exchange || "bybit"), h("div", { class: "ic", onclick: () => { tab = "Сповіщення"; render(); } }, icon("bell")), h("div", { class: "ava", onclick: async () => { await fetch("/logout", { method: "POST", headers: { "X-CSRF": csrf } }); location.href = "/login"; } }))),
    view);
  tick();
}
async function load() {
  const active = document.activeElement;
  S = await api("/api/state");
  if (!S) return;
  csrf = S.csrf; nextAt = Date.now() + S.next_in * 1000;
  if (!(active && (active.tagName === "INPUT" || active.tagName === "SELECT"))) render();
}
setInterval(tick, 1000);
setInterval(load, 20000);
load().then(loadCandles);
